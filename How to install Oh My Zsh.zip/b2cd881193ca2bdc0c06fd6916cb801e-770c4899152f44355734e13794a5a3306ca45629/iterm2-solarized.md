# Default

![Default](https://gist.githubusercontent.com/kevin-smets/9722391f8b3e4fa436b1c1dcf05ecd88/raw/14012c157e280684ae5c75686eef2e302123e51b/agnoster.png)

# Powerlevel9k

![Powerlevel9k](https://gist.githubusercontent.com/kevin-smets/9722391f8b3e4fa436b1c1dcf05ecd88/raw/29389beaa891f939e274b8e20622647357e793d4/powerlevel9k.png)